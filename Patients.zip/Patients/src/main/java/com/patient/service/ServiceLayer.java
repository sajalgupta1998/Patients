package com.patient.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.patient.dao.PatientData;
import com.patient.repository.Repository;

@Service
public class ServiceLayer {
	
	@Autowired
	Repository repo;

	public List<PatientData> getPatient(PatientData data) {
		List<PatientData> l=new ArrayList<PatientData>();
		List<PatientData> l2= new ArrayList<PatientData>();
		l=repo.findAll();
		
		l2=l.stream().filter(dat->dat.getAge()>40).collect(Collectors.toList());
		l.forEach(System.out::println);
		
//		 for(int i=0;i<l.size();i++) {
//			 if(l.get(i).getAge()>40) {
//				 l2.add(l.get(i));
//			 }
//		 }
		
		
		
		 return l2;
	}

	public PatientData add(PatientData data) {
		
		
		return repo.save(data);
	}
	
public PatientData addp(PatientData data) {
		
		if(data.getDisease().equals("maleria")) {
			data.setDoctor(data.getDoctor());
		}
		return repo.save(data);
	}

}
