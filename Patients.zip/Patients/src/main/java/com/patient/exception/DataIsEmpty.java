package com.patient.exception;

public class DataIsEmpty extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public DataIsEmpty(String msg) {
		super(msg);
		
	}

	

}
