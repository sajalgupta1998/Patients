package com.patient.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.patient.dao.PatientData;
import com.patient.service.ServiceLayer;


@RestController
public class Controller {

	@Autowired(required = true)
	ServiceLayer servicelayer;
	
	
	@GetMapping("/getAllPatientsDetails/")
	public List<PatientData> getAllPatient(@RequestBody PatientData data){
		return servicelayer.getPatient(data);
	}
	
	@PostMapping("addPatients")
	public PatientData adddata(@RequestBody PatientData data) {
		
		return servicelayer.add(data);
	}
	
	@PostMapping("adddoctor")
	public PatientData addda(@RequestBody PatientData data) {
		
		return servicelayer.add(data);
	}
}
