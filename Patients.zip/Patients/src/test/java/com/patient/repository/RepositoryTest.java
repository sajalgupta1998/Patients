package com.patient.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.patient.dao.PatientData;

class RepositoryTest {

	@Autowired
	Repository repo;
	@Test
	void add() {
		PatientData p=new PatientData(1, "sajal", "fever", 55, "gelly");
		repo.save(p);
		PatientData pp=repo.findAll());
		
	}
//	@Test
//	void showAll() {
//		List<PatientData> user= repo.findAll();
//    	assertThat(user).size().isGreaterThan(0);
//	}
}
