package com.patient;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.*;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;

import com.patient.dao.PatientData;
import com.patient.repository.Repository;
import com.patient.service.ServiceLayer;

//@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest

class PatientsApplicationTests {

	
    @Mock 
	Repository repo;
	
	@InjectMocks
	ServiceLayer service;
	
	@Order(1)
	@Test
	void add() {
		PatientData p=new PatientData(1, "sajal", "fever", 55, "gelly");
		List<String> l= Arrays.asList("diabetic","high cholestrol","dengue","covid","anthrax","cholera","brain injury","fever");
		repo.save(p);
		boolean tt=l.contains(p.getDisease());
		assertEquals(true, tt);
		
	}
	@Order(2)
	@Test
	void showAll() {
//		List<PatientData> user= repo.findAll();
//    	assertThat(user).size().isGreaterThan(0);
//		List<PatientData> list = new ArrayList<PatientData>();
//		PatientData empOne = new PatientData(1, "sajal", "covid",44, "gelly");
//		PatientData empTwo = new PatientData(2, "aman", "fever",23, "john");
//		PatientData empThree = new PatientData(3, "anushk", "diabetic", 34,"john");
//
//		list.add(empOne);
//		list.add(empTwo);
//		list.add(empThree);
		

		//when(pd.getEmployeeList()).thenReturn(list);
         when(repo.findAll()).thenReturn(Arrays.asList(new PatientData()));
		//test
		List<PatientData> empList = service.showAll();

		assertEquals(1, empList.size());
    	
	}
//	@Test
//	void showPatientTestA() {
//		List<PatientData> list = new ArrayList<PatientData>();
//		PatientData empOne = new PatientData(1, "sajal", "covid",44, "gelly");
//		list.add(empOne);
//		Mockito.when(restTemplate.getForEntity("http://localhost:8080/showAllPatients", PatientData.class))
//		.thenReturn(new ResponseEntity(empOne, HttpStatus.OK));
//		List<PatientData> employee =  service.showAll();
//        assertEquals(list, employee);
//	}
	
//	@Order(3)
//	//updatepatientname/{name}
//	@Test
//	void update() {
//		//PatientData p=new PatientData();
//		List<PatientData> user= repo.findAll();
//		PatientData pd=user.get(0);
//		pd.setName("prashant");
//		repo.save(pd);
//	   assertEquals("prashant",pd.getName());
//		
//	}

}
